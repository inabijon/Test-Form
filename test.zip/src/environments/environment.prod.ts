export const environment = {
  production: true,
  apiUrl: 'http://23.100.5.244:8083/api',
};
